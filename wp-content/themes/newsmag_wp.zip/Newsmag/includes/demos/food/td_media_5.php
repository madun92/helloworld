<?php
/**
 * Created by ra on 6/13/2015.
 */

//logos
td_demo_media::add_image_to_media_gallery('td_logo_header',                'http://demo_content.tagdiv.com/Newsmag/food/logo-header.png');
td_demo_media::add_image_to_media_gallery('td_logo_header_retina',                'http://demo_content.tagdiv.com/Newsmag/food/logo-header-retina.png');


td_demo_media::add_image_to_media_gallery('td_logo_other',                'http://demo_content.tagdiv.com/Newsmag/food/logo-other.png');
td_demo_media::add_image_to_media_gallery('td_logo_other_retina',                'http://demo_content.tagdiv.com/Newsmag/food/logo-other-retina.png');