<?php
/**
 * Created by ra on 6/13/2015.
 */


td_demo_media::add_image_to_media_gallery('td_pic_p2',                  "http://demo_content.tagdiv.com/Newsmag/sport/p2.jpg");
td_demo_media::add_image_to_media_gallery('td_pic_p3',                  "http://demo_content.tagdiv.com/Newsmag/sport/p3.jpg");



td_demo_media::add_image_to_media_gallery('td_pic_7',                   "http://demo_content.tagdiv.com/Newsmag/sport/7.jpg");
td_demo_media::add_image_to_media_gallery('td_pic_8',                   "http://demo_content.tagdiv.com/Newsmag/sport/8.jpg");