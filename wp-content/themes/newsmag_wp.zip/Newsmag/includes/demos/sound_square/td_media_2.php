<?php
/**
 * Created by ra on 6/13/2015.
 */


td_demo_media::add_image_to_media_gallery('td_pic_3',                   "http://demo_content.tagdiv.com/Newsmag/sound_square/3.jpg");
td_demo_media::add_image_to_media_gallery('td_pic_4',                   "http://demo_content.tagdiv.com/Newsmag/sound_square/4.jpg");
td_demo_media::add_image_to_media_gallery('td_pic_5',                   "http://demo_content.tagdiv.com/Newsmag/sound_square/5.jpg");
td_demo_media::add_image_to_media_gallery('td_pic_6',                   "http://demo_content.tagdiv.com/Newsmag/sound_square/6.jpg");
