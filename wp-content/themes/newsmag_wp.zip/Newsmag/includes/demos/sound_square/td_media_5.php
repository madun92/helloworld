<?php
/**
 * Created by ra on 6/13/2015.
 */


td_demo_media::add_image_to_media_gallery('td_mobile_logo',                'http://demo_content.tagdiv.com/Newsmag/sound_square/logo-mobile.png');

//ads
td_demo_media::add_image_to_media_gallery('td_sound_square_custom_rec',       "http://demo_content.tagdiv.com/Newsmag/sound_square/rec-custom.png");
td_demo_media::add_image_to_media_gallery('td_sound_square_sidebar_rec',      "http://demo_content.tagdiv.com/Newsmag/sound_square/rec-sidebar.png");