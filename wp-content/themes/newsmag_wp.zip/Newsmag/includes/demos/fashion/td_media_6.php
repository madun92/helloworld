<?php
/**
 * Created by ra on 6/13/2015.
 */


td_demo_media::add_image_to_media_gallery('td_pic_logo_white',          'http://demo_content.tagdiv.com/Newsmag/fashion/fashion-logo-footer.png');

//ads
td_demo_media::add_image_to_media_gallery('td_fashion_bg',      "http://demo_content.tagdiv.com/Newsmag/fashion/bg.jpg");

