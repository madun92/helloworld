<?php
/**
 * Created by ra on 6/13/2015.
 */

td_demo_media::add_image_to_media_gallery('td_pic_7',                   "http://demo_content.tagdiv.com/Newsmag/animals/7.jpg");
td_demo_media::add_image_to_media_gallery('td_pic_8',                  "http://demo_content.tagdiv.com/Newsmag/animals/8.jpg");
td_demo_media::add_image_to_media_gallery('td_pic_9',                   "http://demo_content.tagdiv.com/Newsmag/animals/9.jpg");
td_demo_media::add_image_to_media_gallery('td_pic_10',                  "http://demo_content.tagdiv.com/Newsmag/animals/10.jpg");