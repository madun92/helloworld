<?php
/**
 * Created by ra on 6/13/2015.
 */
td_demo_media::add_image_to_media_gallery('td_pic_17',                  "http://demo_content.tagdiv.com/Newsmag/default4/17.jpg");
td_demo_media::add_image_to_media_gallery('td_pic_18',                  "http://demo_content.tagdiv.com/Newsmag/default4/18.jpg");
//post images
td_demo_media::add_image_to_media_gallery('td_pic_p1',                  "http://demo_content.tagdiv.com/Newsmag/default4/p1.jpg");
td_demo_media::add_image_to_media_gallery('td_pic_p2',                  "http://demo_content.tagdiv.com/Newsmag/default4/p2.jpg");
