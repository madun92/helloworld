<?php
/**
 * Created by ra on 6/13/2015.
 */

td_demo_media::add_image_to_media_gallery('td_pic_p3',                  "http://demo_content.tagdiv.com/Newsmag/default4/p3.jpg");
td_demo_media::add_image_to_media_gallery('td_pic_p4',                  "http://demo_content.tagdiv.com/Newsmag/default4/p4.jpg");
//logo
td_demo_media::add_image_to_media_gallery('td_pic_logo',                'http://demo_content.tagdiv.com/Newsmag/default4/newsmag.png');
td_demo_media::add_image_to_media_gallery('td_pic_logo_footer',         'http://demo_content.tagdiv.com/Newsmag/default4/newsmag-footer.png');
//ads
td_demo_media::add_image_to_media_gallery('td_default_ad_full',         "http://demo_content.tagdiv.com/Newsmag/default4/rec728.jpg");
td_demo_media::add_image_to_media_gallery('td_default_ad_sidebar',      "http://demo_content.tagdiv.com/Newsmag/default4/rec300.png");
td_demo_media::add_image_to_media_gallery('td_default_ad_tablet',       "http://demo_content.tagdiv.com/Newsmag/default4/rec468.jpg");