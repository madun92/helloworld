<?php
/**
 * Created by ra on 6/13/2015.
 */


//ads
td_demo_media::add_image_to_media_gallery('td_cars_ad_sidebar',              "http://demo_content.tagdiv.com/Newsmag/cars/ad-sidebar.jpg");
td_demo_media::add_image_to_media_gallery('td_cars_big_ad',                  "http://demo_content.tagdiv.com/Newsmag/cars/big_ad.jpg");