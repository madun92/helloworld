<?php
/**
 * Created by ra on 6/13/2015.
 */


//ads
td_demo_media::add_image_to_media_gallery('td_travel_ad_header',        "http://demo_content.tagdiv.com/Newsmag/travel/ad-header.png");
td_demo_media::add_image_to_media_gallery('td_travel_ad_sidebar',       "http://demo_content.tagdiv.com/Newsmag/travel/ad-sidebar.jpg");
td_demo_media::add_image_to_media_gallery('td_travel_ad_big',           "http://demo_content.tagdiv.com/Newsmag/travel/ad-big.jpg");

//bg
td_demo_media::add_image_to_media_gallery('td_travel_bg',                "http://demo_content.tagdiv.com/Newsmag/travel/bg.jpg");