<?php
/**
 * Created by ra on 6/13/2015.
 */



td_demo_media::add_image_to_media_gallery('td_pic_logo_footer',         'http://demo_content.tagdiv.com/Newsmag/tech/logo-footer-tech.png');

//ads
td_demo_media::add_image_to_media_gallery('td_tech_ad_full',            "http://demo_content.tagdiv.com/Newsmag/tech/rec728.jpg");
td_demo_media::add_image_to_media_gallery('td_tech_ad_sidebar',         "http://demo_content.tagdiv.com/Newsmag/tech/rec300.png");

