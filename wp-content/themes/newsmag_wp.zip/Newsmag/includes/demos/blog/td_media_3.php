<?php

td_demo_media::add_image_to_media_gallery('td_pic_7',                   "http://demo_content.tagdiv.com/Newsmag/blog/7.jpg");
td_demo_media::add_image_to_media_gallery('td_pic_8',                   "http://demo_content.tagdiv.com/Newsmag/blog/8.jpg");
td_demo_media::add_image_to_media_gallery('td_pic_9',                   "http://demo_content.tagdiv.com/Newsmag/blog/9.jpg");