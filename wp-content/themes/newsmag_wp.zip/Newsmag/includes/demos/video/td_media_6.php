<?php
/**
 * Created by ra on 6/13/2015.
 */

td_demo_media::add_image_to_media_gallery('td_pic_logo_footer', 'http://demo_content.tagdiv.com/Newsmag/video/logo-footer-video.png');
td_demo_media::add_image_to_media_gallery('td_pic_logo_mobile', 'http://demo_content.tagdiv.com/Newsmag/video/logo-mobile-video.png');

//ads
td_demo_media::add_image_to_media_gallery('td_video_full_ad',           "http://demo_content.tagdiv.com/Newsmag/video/rec728.jpg");
td_demo_media::add_image_to_media_gallery('td_video_sidebar_ad',        "http://demo_content.tagdiv.com/Newsmag/video/rec300.png");